A convolutional neural network which classifies an image into one of 2 classes, a dog or a cat, written in python.
Dataset used to train and test is available at: kaggle.com/c/dogs-vs-cats/data
